package com.example.drawerdelete;

import android.view.View;
import android.widget.TextView;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/** 仅适配 系统桌面 17.5.5（com.android.launcher），类名/字段名均为该版本的混淆名。 */
public class Hook implements IXposedHookLoadPackage {
    private static final String PKG = "com.android.launcher";
    private static boolean swapped;

    @Override
    public void handleLoadPackage(LoadPackageParam lpp) {
        if (!PKG.equals(lpp.packageName)) return;
        ClassLoader cl = lpp.classLoader;
        Class<?> button = XposedHelpers.findClass("com.android.launcher.pagepreview.PagePreviewButtonContainer", cl);
        Class<?> modeMgr = XposedHelpers.findClass("vp5", cl);   // 当前桌面模式的单例，字段 t = 模式
        Class<?> selMgr = XposedHelpers.findClass("in2", cl);    // in2.b(ctx) -> zn2
        Class<?> modeEnum = XposedHelpers.findClass("com.android.launcher.mode.LauncherMode", cl);

        Object drawer = null, standard = null;
        for (Object m : modeEnum.getEnumConstants()) {
            String name = ((Enum<?>) m).name();
            if (name.equals("Drawer")) drawer = m;
            else if (name.equals("Standard")) standard = m;
        }
        final Object drawerMode = drawer, standardMode = standard;

        // 点击右侧按钮：抽屉模式下，若选中项里有可卸载/可移除的，临时按标准模式执行，
        // 直接复用标准模式的"卸载"流程；否则保持原有的"移除"行为（例如只选了系统应用）。
        XposedHelpers.findAndHookMethod(button, "onClick", View.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                Object vp = XposedHelpers.callStaticMethod(modeMgr, "c");
                if (p.args[0] != XposedHelpers.getObjectField(p.thisObject, "c")
                        || XposedHelpers.getObjectField(vp, "t") != drawerMode) return;
                XposedHelpers.setObjectField(vp, "t", standardMode);
                Object launcher = XposedHelpers.getObjectField(p.thisObject, "u");
                Object sel = XposedHelpers.callStaticMethod(selMgr, "b", launcher);
                if ((boolean) XposedHelpers.callMethod(sel, "z", launcher)) {
                    swapped = true;
                } else {
                    XposedHelpers.setObjectField(vp, "t", drawerMode);
                }
            }

            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                if (!swapped) return;
                swapped = false;
                XposedHelpers.setObjectField(XposedHelpers.callStaticMethod(modeMgr, "c"), "t", drawerMode);
            }
        });

        // 文字：原方法在抽屉模式下把按钮设为"移除"，这里改成桌面自带的"卸载"（uninstall_action）
        XposedHelpers.findAndHookMethod(button, "f", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                View c = (View) XposedHelpers.getObjectField(p.thisObject, "c");
                if (c == null || XposedHelpers.getObjectField(p.thisObject, "t") != drawerMode) return;
                TextView q = (TextView) XposedHelpers.getObjectField(p.thisObject, "q");
                q.setText(q.getResources().getIdentifier("uninstall_action", "string", PKG));
                c.setContentDescription(q.getText());
            }
        });
    }
}
